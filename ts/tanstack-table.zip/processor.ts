import { ColumnFiltersState, SortingState } from '@tanstack/react-table';
import filter from './processor/filter';
import { isEmptyValues } from '@uni/utils/src/utils';

export const antSorterToTanstackSorter = (sorterInfo: any) => {
  let tanstackSorter = [];

  tanstackSorter.push({
    id: sorterInfo?.columnKey,
    desc: sorterInfo?.order === 'descend',
  });

  return tanstackSorter;
};

export const sorterProcessor = (sortItems: SortingState) => {
  let sorter: any = {};
  // column: undefined
  // columnKey: "Degree"
  // field: "Degree"
  // order: undefined
  if (sortItems?.length > 1) {
    sorter = [];
    sortItems?.forEach((item) => {
      let sortItem = {};
      sortItem['column'] = item?.id;
      sortItem['columnKey'] = item?.id;
      sortItem['field'] = item?.id;
      sortItem['order'] = item?.desc === true ? 'descend' : 'ascend';
      sorter.push(sortItem);
    });
  } else if (sortItems?.length === 1) {
    sortItems?.forEach((item) => {
      sorter['column'] = item?.id;
      sorter['columnKey'] = item?.id;
      sorter['field'] = item?.id;
      sorter['order'] = item?.desc === true ? 'descend' : 'ascend';
    });
  }

  return sorter;
};

export const filterProcessor = (filterItems: ColumnFiltersState) => {
  let filters = {};

  filterItems?.forEach((filterItem) => {
    if (!isEmptyValues(filterItem?.value)) {
      filters[filterItem?.id] = filterItem?.value;
    }
  });

  return filters;
};
