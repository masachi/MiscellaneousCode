import classNames from 'classnames';
import {
  Button,
  Checkbox,
  Dropdown,
  Empty,
  Input,
  Menu,
  MenuProps,
  Radio,
} from 'antd';
import React, { Key, useState } from 'react';
import { ColumnFilterItem, FilterSearchType } from 'antd/lib/table/interface';
import { FilterFilled, SearchOutlined } from '@ant-design/icons';
import { TreeColumnFilterItem } from 'antd/lib/table/hooks/useFilter/FilterDropdown';
import { FilterState } from 'antd/es/table/hooks/useFilter';
import { BaseColumnOperatorProps } from '../interfaces';
import { isEmptyValues } from '@uni/utils/src/utils';

interface ColumnFilter extends BaseColumnOperatorProps {}

export interface FilterDropdownProps {
  prefixCls: string;
  dropdownPrefixCls: string;
  column: any;
  filterState?: any;
  filterMultiple: boolean;
  filterMode?: 'menu' | 'tree';
  filterSearch?: FilterSearchType<ColumnFilterItem | TreeColumnFilterItem>;
  columnKey: Key;
  triggerFilter: (filterState: FilterState<any>) => void;
  getPopupContainer?: any;
  filterResetToDefaultFilteredValue?: boolean;
}

const ColumnFilter = (props: ColumnFilter) => {
  console.log('ColumnFilter', props);

  return (
    <ColumnFilterDropDown
      prefixCls={'ant-table-filter'}
      dropdownPrefixCls={'ant-dropdown'}
      column={props?.column}
      filterState={{}} // TODO
      filterMultiple={true}
      columnKey={props?.column?.key}
      triggerFilter={(filterState) => {}}
    />
  );
};

function searchValueMatched(searchValue: string, text: React.ReactNode) {
  if (typeof text === 'string' || typeof text === 'number') {
    return text
      ?.toString()
      .toLowerCase()
      .includes(searchValue.trim().toLowerCase());
  }
  return false;
}

// const ColumnFilterDropDown = (props: FilterDropdownProps) => {
const ColumnFilterDropDown = (props: FilterDropdownProps) => {
  const [visible, setVisible] = useState(false);

  const filtered: boolean = props?.column.getFilterValue()?.length > 0;

  const [filteredKeys, setFilteredKeys] = useState(
    Array.isArray(props?.column.getFilterValue())
      ? props?.column.getFilterValue()
      : [],
  );

  const [searchValue, setSearchValue] = useState(
    Array.isArray(props?.column.getFilterValue())
      ? ''
      : props?.column.getFilterValue(),
  );

  const onSelectKeys = ({ selectedKeys }: { selectedKeys: Key[] }) => {
    setFilteredKeys(selectedKeys);
  };

  function renderFilterItems({
    filters,
    prefixCls,
    filteredKeys,
    filterMultiple,
    filterSearch,
  }: {
    filters: ColumnFilterItem[];
    prefixCls: string;
    filteredKeys: Key[];
    filterMultiple: boolean;
    filterSearch: FilterSearchType<ColumnFilterItem>;
  }): Required<MenuProps>['items'] {
    return filters.map((filter, index) => {
      const key = String(filter.value);

      if (filter.children) {
        return {
          key: key || index,
          label: filter.text,
          popupClassName: `ant-table-dropdown-submenu`,
          children: renderFilterItems({
            filters: filter.children,
            prefixCls,
            filteredKeys,
            filterMultiple,
            filterSearch,
          }),
        };
      }

      const Component = filterMultiple ? Checkbox : Radio;

      const item = {
        key: filter.value !== undefined ? key : index,
        label: (
          <>
            <Component checked={filteredKeys.includes(key)} />
            <span>{filter.text}</span>
          </>
        ),
      };
      return item;
    });
  }

  const getFilterComponent = () => {
    if (props?.column?.columnDef?.meta?.filterMeta?.type === 'search') {
      return (
        <FilterSearch
          columnName={props?.column?.columnDef?.header}
          filterSearch={
            props?.column?.columnDef?.meta?.filterMeta?.type === 'search'
          }
          value={searchValue}
          onChange={(event) => {
            setSearchValue(event?.target?.value);
          }}
        />
      );
    }

    if (
      (props?.column?.columnDef?.meta?.filterMeta?.filters || []).length === 0
    ) {
      return (
        <Empty
          image={Empty.PRESENTED_IMAGE_SIMPLE}
          description={'暂无数据'}
          imageStyle={{
            height: 24,
          }}
          style={{
            margin: 0,
            padding: '16px 0',
          }}
        />
      );
    }
    return (
      <>
        <Menu
          selectable
          multiple={true}
          prefixCls={`ant-dropdown-menu`}
          className={'ant-dropdown-menu-without-submenu'}
          onSelect={onSelectKeys}
          onDeselect={onSelectKeys}
          selectedKeys={filteredKeys}
          items={renderFilterItems({
            filters: props?.column?.columnDef?.meta?.filterMeta?.filters || [],
            filterSearch:
              props?.column?.columnDef?.meta?.filterMeta?.filterSearch ?? true,
            prefixCls: 'ant-dropdown',
            filteredKeys: filteredKeys,
            filterMultiple:
              props?.column?.columnDef?.meta?.filterMeta?.filterMultiple ??
              true,
            // searchValue: "",// TODO
          })}
        />
      </>
    );
  };

  const triggerVisible = (newVisible: boolean) => {
    setVisible(newVisible);
  };

  const onConfirm = () => {
    if (props?.column?.columnDef?.meta?.filterMeta?.type === 'search') {
      props?.column.setFilterValue(searchValue);
    }
    if (props?.column?.columnDef?.meta?.filterMeta?.type === 'filter') {
      props?.column.setFilterValue(filteredKeys);
    }
  };

  const onVisibleChange = (newVisible: boolean) => {
    triggerVisible(newVisible);

    if (!newVisible) {
      onConfirm();
    }
  };

  const getResetDisable = () => {
    if (props?.column?.columnDef?.meta?.filterMeta?.type === 'search') {
      return isEmptyValues(searchValue);
    }
    if (props?.column?.columnDef?.meta?.filterMeta?.type === 'filter') {
      return filteredKeys?.length === 0;
    }

    return false;
  };

  return (
    <Dropdown
      dropdownRender={() => {
        return (
          <div
            className={`ant-table-filter-dropdown`}
            onClick={(e) => e.stopPropagation()}
          >
            <>
              {getFilterComponent()}
              <div className={`ant-table-filter-dropdown-btns`}>
                <Button
                  type="link"
                  size="small"
                  disabled={getResetDisable()}
                  onClick={() => {
                    setSearchValue(undefined);
                    setFilteredKeys(undefined);
                  }}
                >
                  重置
                </Button>
                <Button
                  type="primary"
                  size="small"
                  onClick={() => {
                    onConfirm();
                    triggerVisible(false);
                  }}
                >
                  确认
                </Button>
              </div>
            </>
          </div>
        );
      }}
      trigger={['click']}
      open={visible}
      onOpenChange={onVisibleChange}
      getPopupContainer={(triggerNode) =>
        document.getElementById('tanstack-table-container')
      }
      placement={'bottomRight'}
    >
      <span
        role="button"
        tabIndex={-1}
        style={{
          minHeight: 30,
          display: 'flex',
          alignItems: 'center',
        }}
        className={classNames(`ant-table-filter-trigger`, {
          active: filtered,
        })}
        onClick={(e) => {
          e.stopPropagation();
        }}
      >
        {props?.column?.columnDef?.meta?.filterMeta?.type === 'search' && (
          <SearchOutlined />
        )}
        {props?.column?.columnDef?.meta?.filterMeta?.type === 'filter' && (
          <FilterFilled />
        )}
      </span>
    </Dropdown>
  );
};

interface FilterSearchProps {
  columnName: string;
  filterSearch?: boolean;
  value?: string;
  onChange?: (event) => void;
}

export const FilterSearch = (props: FilterSearchProps) => {
  console.log();

  if (!props?.filterSearch) {
    return null;
  }
  return (
    <div className={`ant-table-filter-dropdown-search`}>
      <Input
        prefix={<SearchOutlined />}
        placeholder={`搜索：${props?.columnName}`}
        onChange={props?.onChange}
        value={props?.value}
        // for skip min-width of input
        htmlSize={1}
        className={`ant-table-filter-dropdown-search-input`}
      />
    </div>
  );
};

export default ColumnFilter;
