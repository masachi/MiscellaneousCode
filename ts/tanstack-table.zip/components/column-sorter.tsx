import { CaretDownOutlined, CaretUpOutlined } from '@ant-design/icons';
import classNames from 'classnames';
import { Tooltip } from 'antd';
import React from 'react';
import { BaseColumnOperatorProps } from '../interfaces';

const ASCEND = 'asc';
const DESCEND = 'desc';

export const toolTipLabel = {
  false: '点击升序',
  asc: '点击降序',
  desc: '取消排序',
};

interface ColumnSorter extends BaseColumnOperatorProps {
  sorterOrder?: string;
}
const ColumnSorter = (props: ColumnSorter) => {
  let sortDirections = [ASCEND, DESCEND];

  let sorterOrder = props?.column?.getIsSorted();

  const upNode: React.ReactNode = sortDirections.includes(ASCEND) && (
    <CaretUpOutlined
      className={classNames(`ant-table-column-sorter-up`, {
        active: sorterOrder === ASCEND,
      })}
      role="presentation"
    />
  );
  const downNode: React.ReactNode = sortDirections.includes(DESCEND) && (
    <CaretDownOutlined
      className={classNames(`ant-table-column-sorter-down`, {
        active: sorterOrder === DESCEND,
      })}
      role="presentation"
    />
  );

  return (
    <span className={'ant-table-column-sorter ant-table-column-sorter-full'}>
      <span className={'ant-table-column-sorter-inner'}>
        {upNode}
        {downNode}
      </span>
    </span>
  );
};

export default ColumnSorter;
