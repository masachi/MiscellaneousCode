import React from 'react';

export interface BaseColumnOperatorProps {
  column: any;
}

type RowClassNameFunction = (record: any, index: number) => string;

export interface RowProps {
  rowClassName?: string | RowClassNameFunction;
  onRow?: (
    data: any,
    index?: number,
  ) => React.HTMLAttributes<any> | React.TdHTMLAttributes<any>;

  canRowSortable?: (row: any) => boolean;
  rowBaseSort?: boolean;
}

export interface SummaryProps {
  summary?: any;
}
