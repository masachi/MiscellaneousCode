import { isEmptyValues } from '@uni/utils/src/utils';

export class TanstackTableMiddleware {
  tableInstance: any;

  columnVisibility = {};
  columnPinned = {
    left: [],
    right: [],
  };

  columnSorters = [];

  constructor(tableInstance: any) {
    this.tableInstance = tableInstance;
  }

  process = (columnItem: any) => {
    let middlewares = [this.visibleMiddleware, this.leftRightPinnedMiddleware];

    middlewares?.forEach((middlewareMethod) => {
      middlewareMethod(columnItem);
    });
  };

  commit = () => {
    this.tableInstance.setColumnVisibility(this.columnVisibility);
    this.tableInstance.setColumnPinning(this.columnPinned);
    if (!isEmptyValues(this.columnSorters)) {
      this.tableInstance.setSorting(this.columnSorters);
    }
  };

  visibleMiddleware = (columnItem: any) => {
    this.columnVisibility[columnItem?.id] = !isEmptyValues(
      columnItem?.meta?.hideInTable,
    )
      ? !columnItem?.meta?.hideInTable
      : columnItem?.meta?.visible;
  };

  leftRightPinnedMiddleware = (columnItem: any) => {
    if (columnItem?.meta?.fixed === 'left') {
      this.columnPinned['left'].push(columnItem?.id);
    }

    if (columnItem?.meta?.fixed === 'right') {
      this.columnPinned['right'].push(columnItem?.id);
    }
  };

  sortMiddleware = (columns: any[]) => {
    let sorters = [];
    columns?.forEach((columnItem) => {
      if (
        columnItem?.orderPriority !== 0 &&
        !isEmptyValues(columnItem?.orderMode)
      ) {
        sorters.push({
          id: columnItem?.dataIndex,
          desc: columnItem?.orderMode === 'descend',
        });
      }
    });

    this.columnSorters = sorters;
  };
}
