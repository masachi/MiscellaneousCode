import { processSummaryData } from '../../table/processor/data/summary-data';
import { v4 as uuidv4 } from 'uuid';
import isEqual from 'lodash/isEqual';

export interface DataSourceProcessorProps {
  // dataProcessor
  dataItemProcessor?: (dataItem: any, index: number) => any;
  needSummary?: boolean;
  summaryDataIndex?: string;
  summaryExcludeKeys?: string[];
  summaryData?: any;
}

export const processTableDataSource = (
  dataSource: any[],
  props: DataSourceProcessorProps,
  setTableDataSource?: any,
  currentTableDataSource?: any[],
) => {
  let tableDataSource = dataSource || [];
  // TODO 处理 dataSource
  tableDataSource = tableDataSource.slice().map((item, index) => {
    if (props?.dataItemProcessor) {
      item = Object.assign({}, props?.dataItemProcessor(item, index));
    }
    return commonDataSourceProcessor(item);
  });

  if (props?.needSummary && props?.summaryDataIndex) {
    tableDataSource = processSummaryData(
      tableDataSource,
      props?.summaryDataIndex,
      props?.summaryData,
      props?.summaryExcludeKeys,
    ).slice();
  }

  if (setTableDataSource) {
    if (!isEqual(currentTableDataSource, tableDataSource)) {
      setTableDataSource(tableDataSource);
    }
  }

  return tableDataSource;
};

const commonDataSourceProcessor = (dataSourceItem) => {
  return {
    id: uuidv4(),
    ...dataSourceItem,
  };
};
