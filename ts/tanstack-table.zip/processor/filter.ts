const FilterItemProcessor = (
  columnItem: any,
  backendPagination: boolean | object,
  infiniteScroll: boolean,
) => {
  let filter = {};

  if (
    columnItem?.filterType === 'filter' ||
    columnItem?.filterType === 'search'
  ) {
    // meta data
    columnItem['filterMeta'] = {};
    columnItem['filterMeta']['type'] = columnItem?.filterType;

    filter['enableColumnFilter'] = true;
    filter['filterFn'] =
      backendPagination || infiniteScroll
        ? undefined
        : (row: any, columnId: string, filterValue: any, addMeta: any) => {
            return row[columnId]
              ? row['onFilter']
                ? row['onFilter'](filterValue, row)
                : onFilterHandler(filterValue, row, [columnId])
              : false;
          };
    if (columnItem?.filterType === 'filter') {
      columnItem['filterMeta']['filters'] =
        columnItem?.filters && columnItem?.filters?.length > 0
          ? columnItem?.filters
          : filtersGenerator(
              columnItem?.dataSource,
              columnItem?.dataIndex,
              columnItem.columnItem?.dictionaryModule,
              columnItem?.dictData,
            );

      columnItem['filterMeta']['filterMultiple'] = true;
      columnItem['filterMeta']['filterSearch'] = true;
    }
  }

  return filter;
};

const onFilterHandler = (value, record, dataKeys: string[]) => {
  let hasMatched = false;
  for (let dataKey of dataKeys) {
    hasMatched = record[dataKey].toString().includes(value);
    if (hasMatched) {
      break;
    }
  }

  return hasMatched;
};

const filtersGenerator = (
  dataSource: any[],
  dataIndex: string,
  dataDictionaryModule: string = null,
  dictData = {},
) => {
  let filterValues = [];

  (dataSource || [])
    ?.filter((item) => item?.[dataIndex])
    ?.forEach((item) => {
      filterValues.push(item?.[dataIndex]);
    });
  return [...new Set(filterValues)]?.map((value) => {
    return {
      text: dictData?.[dataDictionaryModule]
        ? dictData?.[dataDictionaryModule]?.find(
            (d) => d.Code?.toString() === value?.toString(),
          )?.Name
        : value,
      value: value,
    };
  });
};

export default FilterItemProcessor;
