import { isEmptyValues } from '@uni/utils/src/utils';

export const headerTextStyleProcessor = (columnItem: any) => {
  let mergedStyle = {};

  if (!isEmptyValues(columnItem?.textOverflowType)) {
    switch (columnItem?.textOverflowType) {
      case 'ellipse':
        mergedStyle = {
          display: 'block',
          overflow: 'hidden',
          whiteSpace: 'nowrap',
          textOverflow: 'ellipsis',
        };
        break;
      case 'clip':
        mergedStyle = {
          display: 'block',
          overflow: 'hidden',
          whiteSpace: 'nowrap',
          textOverflow: 'clip',
        };
        break;
      default:
        break;
    }
  }

  return mergedStyle;
};

export const contentTextStyleProcessor = (columnItem: any) => {
  let mergedStyle = {};

  if (!isEmptyValues(columnItem?.textOverflowType)) {
    switch (columnItem?.textOverflowType) {
      case 'ellipse':
        mergedStyle = {
          whiteSpace: 'nowrap',
          textOverflow: 'ellipsis',
          overflow: 'hidden',
          width: '100%',
          display: 'block',
        };
        break;
      case 'clip':
        mergedStyle = {
          whiteSpace: 'nowrap',
          textOverflow: 'clip',
          overflow: 'hidden',
          width: '100%',
          display: 'block',
        };
        break;
      default:
        break;
    }
  }

  return mergedStyle;
};
